/*
 * ============================================================================
 * PROYECTO: ALGORITMOS DE REEMPLAZO DE PÁGINAS
 * Curso: Sistemas Operativos
 * Descripción: Simulador en lenguaje C de 12 algoritmos de sustitución de
 *              páginas empleando M = 3 marcos de memoria física y una
 *              secuencia estandarizada de N = 30 referencias a páginas,
 *              basado en la arquitectura funcional de:
 *              https://mi-simulador-paginacion.vercel.app/
 *
 * Distribución del Equipo (6 Integrantes - 2 Algoritmos por Integrante):
 *   - Integrante 1: FIFO (First-In, First-Out) y Óptimo (OPT / Belady)
 *   - Integrante 2: LRU (Least Recently Used) y Reloj (Clock / 2da Oportunidad)
 *   - Integrante 3: NRU (Not Recently Used) y LFU (Least Frequently Used)
 *   - Integrante 4: MFU (Most Frequently Used) y Reloj Mejorado (GCLOCK R,M)
 *   - Integrante 5: Aging (Envejecimiento) y Working Set (Conjunto de Trabajo)
 *   - Integrante 6: WSClock y Aleatorio (Random Replacement)
 * ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MARCOS 3
#define NUM_REFS 30
#define NUM_ALGOS 12

typedef struct {
    char nombre[32];
    char integrante[32];
    int historial[MARCOS][NUM_REFS];
    int estado_hit[NUM_REFS]; /* 1 = Hit (Acierto), 0 = Fault (Fallo) */
    int fallos;
    int aciertos;
    double tasa_fallos;
    double tasa_aciertos;
} ResultadoAlgoritmo;

static const int REFS_DEFECTO[NUM_REFS] = {
    7, 0, 1, 2, 0, 3, 0, 4, 2, 3,
    0, 3, 2, 1, 2, 0, 1, 7, 0, 1,
    3, 4, 2, 1, 0, 3, 2, 4, 1, 0
};

static void inicializar_resultado(ResultadoAlgoritmo *res, const char *nombre, const char *integrante) {
    strncpy(res->nombre, nombre, 31);
    res->nombre[31] = '\0';
    strncpy(res->integrante, integrante, 31);
    res->integrante[31] = '\0';
    res->fallos = 0;
    res->aciertos = 0;
    for (int f = 0; f < MARCOS; f++) {
        for (int t = 0; t < NUM_REFS; t++) {
            res->historial[f][t] = -1;
        }
    }
    for (int t = 0; t < NUM_REFS; t++) {
        res->estado_hit[t] = 0;
    }
}

static int buscar_pagina(const int marcos[], int m, int pagina) {
    for (int i = 0; i < m; i++) {
        if (marcos[i] == pagina) return i;
    }
    return -1;
}

static void registrar_paso(ResultadoAlgoritmo *res, const int marcos[], int paso, int hit) {
    for (int f = 0; f < MARCOS; f++) {
        res->historial[f][paso] = marcos[f];
    }
    res->estado_hit[paso] = hit;
    if (hit) res->aciertos++;
    else res->fallos++;
}

static void finalizar_metricas(ResultadoAlgoritmo *res) {
    res->tasa_fallos = ((double)res->fallos / (double)NUM_REFS) * 100.0;
    res->tasa_aciertos = ((double)res->aciertos / (double)NUM_REFS) * 100.0;
}

/* 1. Algoritmo FIFO (First-In, First-Out) */
void simular_fifo(const int refs[], ResultadoAlgoritmo *res) {
    inicializar_resultado(res, "FIFO", "Integrante 1");
    int marcos[MARCOS] = {-1, -1, -1};
    int puntero = 0;

    for (int i = 0; i < NUM_REFS; i++) {
        int pag = refs[i];
        int idx = buscar_pagina(marcos, MARCOS, pag);
        if (idx != -1) {
            registrar_paso(res, marcos, i, 1);
        } else {
            marcos[puntero] = pag;
            puntero = (puntero + 1) % MARCOS;
            registrar_paso(res, marcos, i, 0);
        }
    }
    finalizar_metricas(res);
}

/* 2. Algoritmo Óptimo (OPT / Belady) */
void simular_optimo(const int refs[], ResultadoAlgoritmo *res) {
    inicializar_resultado(res, "Optimo (OPT)", "Integrante 1");
    int marcos[MARCOS] = {-1, -1, -1};

    for (int i = 0; i < NUM_REFS; i++) {
        int pag = refs[i];
        int idx = buscar_pagina(marcos, MARCOS, pag);
        if (idx != -1) {
            registrar_paso(res, marcos, i, 1);
        } else {
            int libre = buscar_pagina(marcos, MARCOS, -1);
            if (libre != -1) {
                marcos[libre] = pag;
            } else {
                int mas_lejano = -1;
                int victima = 0;
                for (int f = 0; f < MARCOS; f++) {
                    int dist = -1;
                    for (int k = i + 1; k < NUM_REFS; k++) {
                        if (refs[k] == marcos[f]) {
                            dist = k - (i + 1);
                            break;
                        }
                    }
                    if (dist == -1) {
                        victima = f;
                        break;
                    }
                    if (dist > mas_lejano) {
                        mas_lejano = dist;
                        victima = f;
                    }
                }
                marcos[victima] = pag;
            }
            registrar_paso(res, marcos, i, 0);
        }
    }
    finalizar_metricas(res);
}

/* 3. Algoritmo LRU (Least Recently Used) */
void simular_lru(const int refs[], ResultadoAlgoritmo *res) {
    inicializar_resultado(res, "LRU", "Integrante 2");
    int marcos[MARCOS] = {-1, -1, -1};
    int ultimo_uso[MARCOS] = {-1, -1, -1};

    for (int i = 0; i < NUM_REFS; i++) {
        int pag = refs[i];
        int idx = buscar_pagina(marcos, MARCOS, pag);
        if (idx != -1) {
            ultimo_uso[idx] = i;
            registrar_paso(res, marcos, i, 1);
        } else {
            int libre = buscar_pagina(marcos, MARCOS, -1);
            int victima = 0;
            if (libre != -1) {
                victima = libre;
            } else {
                for (int f = 1; f < MARCOS; f++) {
                    if (ultimo_uso[f] < ultimo_uso[victima]) {
                        victima = f;
                    }
                }
            }
            marcos[victima] = pag;
            ultimo_uso[victima] = i;
            registrar_paso(res, marcos, i, 0);
        }
    }
    finalizar_metricas(res);
}

/* 4. Algoritmo del Reloj (Clock / Segunda Oportunidad) */
void simular_reloj(const int refs[], ResultadoAlgoritmo *res) {
    inicializar_resultado(res, "Reloj (Clock)", "Integrante 2");
    int marcos[MARCOS] = {-1, -1, -1};
    int bit_uso[MARCOS] = {0, 0, 0};
    int puntero = 0;

    for (int i = 0; i < NUM_REFS; i++) {
        int pag = refs[i];
        int idx = buscar_pagina(marcos, MARCOS, pag);
        if (idx != -1) {
            bit_uso[idx] = 1;
            registrar_paso(res, marcos, i, 1);
        } else {
            while (1) {
                if (marcos[puntero] == -1 || bit_uso[puntero] == 0) {
                    marcos[puntero] = pag;
                    bit_uso[puntero] = 1;
                    puntero = (puntero + 1) % MARCOS;
                    break;
                } else {
                    bit_uso[puntero] = 0;
                    puntero = (puntero + 1) % MARCOS;
                }
            }
            registrar_paso(res, marcos, i, 0);
        }
    }
    finalizar_metricas(res);
}

/* 5. Algoritmo NRU (Not Recently Used) */
void simular_nru(const int refs[], ResultadoAlgoritmo *res) {
    inicializar_resultado(res, "NRU", "Integrante 3");
    int marcos[MARCOS] = {-1, -1, -1};
    int bit_r[MARCOS] = {0, 0, 0};
    int bit_m[MARCOS] = {0, 0, 0};
    int llegada[MARCOS] = {0, 0, 0};

    for (int i = 0; i < NUM_REFS; i++) {
        if (i > 0 && i % 5 == 0) {
            for (int f = 0; f < MARCOS; f++) bit_r[f] = 0;
        }
        int escritura = (i % 3 == 0) ? 1 : 0;
        int pag = refs[i];
        int idx = buscar_pagina(marcos, MARCOS, pag);
        if (idx != -1) {
            bit_r[idx] = 1;
            if (escritura) bit_m[idx] = 1;
            registrar_paso(res, marcos, i, 1);
        } else {
            int libre = buscar_pagina(marcos, MARCOS, -1);
            int victima = 0;
            if (libre != -1) {
                victima = libre;
            } else {
                int mejor_clase = 2 * bit_r[0] + bit_m[0];
                int mejor_llegada = llegada[0];
                for (int f = 1; f < MARCOS; f++) {
                    int clase = 2 * bit_r[f] + bit_m[f];
                    if (clase < mejor_clase || (clase == mejor_clase && llegada[f] < mejor_llegada)) {
                        mejor_clase = clase;
                        mejor_llegada = llegada[f];
                        victima = f;
                    }
                }
            }
            marcos[victima] = pag;
            bit_r[victima] = 1;
            bit_m[victima] = escritura;
            llegada[victima] = i;
            registrar_paso(res, marcos, i, 0);
        }
    }
    finalizar_metricas(res);
}

/* 6. Algoritmo LFU (Least Frequently Used) */
void simular_lfu(const int refs[], ResultadoAlgoritmo *res) {
    inicializar_resultado(res, "LFU", "Integrante 3");
    int marcos[MARCOS] = {-1, -1, -1};
    int freq[MARCOS] = {0, 0, 0};
    int llegada[MARCOS] = {0, 0, 0};

    for (int i = 0; i < NUM_REFS; i++) {
        int pag = refs[i];
        int idx = buscar_pagina(marcos, MARCOS, pag);
        if (idx != -1) {
            freq[idx]++;
            registrar_paso(res, marcos, i, 1);
        } else {
            int libre = buscar_pagina(marcos, MARCOS, -1);
            int victima = 0;
            if (libre != -1) {
                victima = libre;
            } else {
                for (int f = 1; f < MARCOS; f++) {
                    if (freq[f] < freq[victima] || (freq[f] == freq[victima] && llegada[f] < llegada[victima])) {
                        victima = f;
                    }
                }
            }
            marcos[victima] = pag;
            freq[victima] = 1;
            llegada[victima] = i;
            registrar_paso(res, marcos, i, 0);
        }
    }
    finalizar_metricas(res);
}

/* 7. Algoritmo MFU (Most Frequently Used) */
void simular_mfu(const int refs[], ResultadoAlgoritmo *res) {
    inicializar_resultado(res, "MFU", "Integrante 4");
    int marcos[MARCOS] = {-1, -1, -1};
    int freq[MARCOS] = {0, 0, 0};
    int llegada[MARCOS] = {0, 0, 0};

    for (int i = 0; i < NUM_REFS; i++) {
        int pag = refs[i];
        int idx = buscar_pagina(marcos, MARCOS, pag);
        if (idx != -1) {
            freq[idx]++;
            registrar_paso(res, marcos, i, 1);
        } else {
            int libre = buscar_pagina(marcos, MARCOS, -1);
            int victima = 0;
            if (libre != -1) {
                victima = libre;
            } else {
                for (int f = 1; f < MARCOS; f++) {
                    if (freq[f] > freq[victima] || (freq[f] == freq[victima] && llegada[f] < llegada[victima])) {
                        victima = f;
                    }
                }
            }
            marcos[victima] = pag;
            freq[victima] = 1;
            llegada[victima] = i;
            registrar_paso(res, marcos, i, 0);
        }
    }
    finalizar_metricas(res);
}

/* 8. Algoritmo Reloj Mejorado (Enhanced Second Chance / GCLOCK) */
void simular_reloj_mejorado(const int refs[], ResultadoAlgoritmo *res) {
    inicializar_resultado(res, "Reloj Mejorado", "Integrante 4");
    int marcos[MARCOS] = {-1, -1, -1};
    int bit_r[MARCOS] = {0, 0, 0};
    int bit_m[MARCOS] = {0, 0, 0};
    int puntero = 0;

    for (int i = 0; i < NUM_REFS; i++) {
        int escritura = (i % 2 == 0) ? 1 : 0;
        int pag = refs[i];
        int idx = buscar_pagina(marcos, MARCOS, pag);
        if (idx != -1) {
            bit_r[idx] = 1;
            if (escritura) bit_m[idx] = 1;
            registrar_paso(res, marcos, i, 1);
        } else {
            int libre = buscar_pagina(marcos, MARCOS, -1);
            if (libre != -1) {
                marcos[libre] = pag;
                bit_r[libre] = 1;
                bit_m[libre] = escritura;
                puntero = (libre + 1) % MARCOS;
            } else {
                int reemplazado = 0;
                for (int vuelta = 0; vuelta < 2 && !reemplazado; vuelta++) {
                    for (int k = 0; k < MARCOS; k++) {
                        if (bit_r[puntero] == 0 && bit_m[puntero] == 0) {
                            marcos[puntero] = pag;
                            bit_r[puntero] = 1;
                            bit_m[puntero] = escritura;
                            puntero = (puntero + 1) % MARCOS;
                            reemplazado = 1;
                            break;
                        }
                        puntero = (puntero + 1) % MARCOS;
                    }
                    if (reemplazado) break;
                    for (int k = 0; k < MARCOS; k++) {
                        if (bit_r[puntero] == 0 && bit_m[puntero] == 1) {
                            marcos[puntero] = pag;
                            bit_r[puntero] = 1;
                            bit_m[puntero] = escritura;
                            puntero = (puntero + 1) % MARCOS;
                            reemplazado = 1;
                            break;
                        }
                        bit_r[puntero] = 0;
                        puntero = (puntero + 1) % MARCOS;
                    }
                }
            }
            registrar_paso(res, marcos, i, 0);
        }
    }
    finalizar_metricas(res);
}

/* 9. Algoritmo Aging (Envejecimiento por registro de desplazamiento de 8 bits) */
void simular_aging(const int refs[], ResultadoAlgoritmo *res) {
    inicializar_resultado(res, "Aging", "Integrante 5");
    int marcos[MARCOS] = {-1, -1, -1};
    unsigned int edad[MARCOS] = {0, 0, 0};

    for (int i = 0; i < NUM_REFS; i++) {
        for (int f = 0; f < MARCOS; f++) {
            edad[f] >>= 1;
        }
        int pag = refs[i];
        int idx = buscar_pagina(marcos, MARCOS, pag);
        if (idx != -1) {
            edad[idx] |= 128U;
            registrar_paso(res, marcos, i, 1);
        } else {
            int libre = buscar_pagina(marcos, MARCOS, -1);
            int victima = 0;
            if (libre != -1) {
                victima = libre;
            } else {
                for (int f = 1; f < MARCOS; f++) {
                    if (edad[f] < edad[victima]) {
                        victima = f;
                    }
                }
            }
            marcos[victima] = pag;
            edad[victima] = 128U;
            registrar_paso(res, marcos, i, 0);
        }
    }
    finalizar_metricas(res);
}

/* 10. Algoritmo Working Set (Conjunto de Trabajo con ventana tau = 3) */
void simular_working_set(const int refs[], ResultadoAlgoritmo *res) {
    inicializar_resultado(res, "Working Set", "Integrante 5");
    int marcos[MARCOS] = {-1, -1, -1};
    int ultimo_uso[MARCOS] = {-1, -1, -1};
    const int tau = 3;

    for (int i = 0; i < NUM_REFS; i++) {
        int pag = refs[i];
        int idx = buscar_pagina(marcos, MARCOS, pag);
        if (idx != -1) {
            ultimo_uso[idx] = i;
            registrar_paso(res, marcos, i, 1);
        } else {
            int libre = buscar_pagina(marcos, MARCOS, -1);
            int victima = -1;
            if (libre != -1) {
                victima = libre;
            } else {
                int mas_antiguo = 999999;
                for (int f = 0; f < MARCOS; f++) {
                    if (i - ultimo_uso[f] > tau && ultimo_uso[f] < mas_antiguo) {
                        mas_antiguo = ultimo_uso[f];
                        victima = f;
                    }
                }
                if (victima == -1) {
                    victima = 0;
                    for (int f = 1; f < MARCOS; f++) {
                        if (ultimo_uso[f] < ultimo_uso[victima]) victima = f;
                    }
                }
            }
            marcos[victima] = pag;
            ultimo_uso[victima] = i;
            registrar_paso(res, marcos, i, 0);
        }
    }
    finalizar_metricas(res);
}

/* 11. Algoritmo WSClock (Working Set Clock con tau = 3) */
void simular_wsclock(const int refs[], ResultadoAlgoritmo *res) {
    inicializar_resultado(res, "WSClock", "Integrante 6");
    int marcos[MARCOS] = {-1, -1, -1};
    int bit_r[MARCOS] = {0, 0, 0};
    int ultimo_uso[MARCOS] = {0, 0, 0};
    int puntero = 0;
    const int tau = 3;

    for (int i = 0; i < NUM_REFS; i++) {
        int pag = refs[i];
        int idx = buscar_pagina(marcos, MARCOS, pag);
        if (idx != -1) {
            bit_r[idx] = 1;
            ultimo_uso[idx] = i;
            registrar_paso(res, marcos, i, 1);
        } else {
            int libre = buscar_pagina(marcos, MARCOS, -1);
            if (libre != -1) {
                marcos[libre] = pag;
                bit_r[libre] = 1;
                ultimo_uso[libre] = i;
                puntero = (libre + 1) % MARCOS;
            } else {
                int reemplazado = 0;
                for (int k = 0; k < MARCOS; k++) {
                    if (bit_r[puntero] == 1) {
                        bit_r[puntero] = 0;
                        ultimo_uso[puntero] = i;
                    } else if (i - ultimo_uso[puntero] > tau) {
                        marcos[puntero] = pag;
                        bit_r[puntero] = 1;
                        ultimo_uso[puntero] = i;
                        puntero = (puntero + 1) % MARCOS;
                        reemplazado = 1;
                        break;
                    }
                    puntero = (puntero + 1) % MARCOS;
                }
                if (!reemplazado) {
                    int victima = 0;
                    for (int f = 1; f < MARCOS; f++) {
                        if (ultimo_uso[f] < ultimo_uso[victima]) victima = f;
                    }
                    marcos[victima] = pag;
                    bit_r[victima] = 1;
                    ultimo_uso[victima] = i;
                    puntero = (victima + 1) % MARCOS;
                }
            }
            registrar_paso(res, marcos, i, 0);
        }
    }
    finalizar_metricas(res);
}

/* 12. Algoritmo Aleatorio (Random Replacement con LCG determinista semilla = 42) */
void simular_aleatorio(const int refs[], ResultadoAlgoritmo *res) {
    inicializar_resultado(res, "Aleatorio (RAND)", "Integrante 6");
    int marcos[MARCOS] = {-1, -1, -1};
    unsigned int semilla = 42U;

    for (int i = 0; i < NUM_REFS; i++) {
        int pag = refs[i];
        int idx = buscar_pagina(marcos, MARCOS, pag);
        if (idx != -1) {
            registrar_paso(res, marcos, i, 1);
        } else {
            int libre = buscar_pagina(marcos, MARCOS, -1);
            int victima = 0;
            if (libre != -1) {
                victima = libre;
            } else {
                semilla = (1103515245U * semilla + 12345U) & 0x7fffffffU;
                victima = (int)(semilla % MARCOS);
            }
            marcos[victima] = pag;
            registrar_paso(res, marcos, i, 0);
        }
    }
    finalizar_metricas(res);
}

void imprimir_matriz_algoritmo(const int refs[], const ResultadoAlgoritmo *res) {
    printf("\n====================================================================================================\n");
    printf(" ALGORITMO: %-20s | RESPONSABLE: %-15s\n", res->nombre, res->integrante);
    printf("====================================================================================================\n");
    printf("Ref:   ");
    for (int t = 0; t < NUM_REFS; t++) printf("%2d ", refs[t]);
    printf("\n----------------------------------------------------------------------------------------------------\n");
    for (int f = 0; f < MARCOS; f++) {
        printf("M[%d]:  ", f);
        for (int t = 0; t < NUM_REFS; t++) {
            if (res->historial[f][t] == -1) printf(" - ");
            else printf("%2d ", res->historial[f][t]);
        }
        printf("\n");
    }
    printf("Est:   ");
    for (int t = 0; t < NUM_REFS; t++) {
        printf(" %c ", res->estado_hit[t] ? 'H' : 'F');
    }
    printf("\n----------------------------------------------------------------------------------------------------\n");
    printf("Fallos de Pagina (F): %2d | Aciertos (H): %2d | Tasa Fallos: %6.2f%% | Tasa Aciertos: %6.2f%%\n",
           res->fallos, res->aciertos, res->tasa_fallos, res->tasa_aciertos);
}

void exportar_csv(const char *ruta, const ResultadoAlgoritmo resultados[]) {
    FILE *fp = fopen(ruta, "w");
    if (!fp) return;
    fprintf(fp, "ID,Algoritmo,Responsable,Marcos,Referencias,Fallos,Aciertos,Tasa_Fallos_Pct,Tasa_Aciertos_Pct\n");
    for (int i = 0; i < NUM_ALGOS; i++) {
        fprintf(fp, "%d,\"%s\",\"%s\",%d,%d,%d,%d,%.2f,%.2f\n",
                i + 1,
                resultados[i].nombre,
                resultados[i].integrante,
                MARCOS,
                NUM_REFS,
                resultados[i].fallos,
                resultados[i].aciertos,
                resultados[i].tasa_fallos,
                resultados[i].tasa_aciertos);
    }
    fclose(fp);
}

int main(void) {
    ResultadoAlgoritmo resultados[NUM_ALGOS];

    simular_fifo(REFS_DEFECTO, &resultados[0]);
    simular_optimo(REFS_DEFECTO, &resultados[1]);
    simular_lru(REFS_DEFECTO, &resultados[2]);
    simular_reloj(REFS_DEFECTO, &resultados[3]);
    simular_nru(REFS_DEFECTO, &resultados[4]);
    simular_lfu(REFS_DEFECTO, &resultados[5]);
    simular_mfu(REFS_DEFECTO, &resultados[6]);
    simular_reloj_mejorado(REFS_DEFECTO, &resultados[7]);
    simular_aging(REFS_DEFECTO, &resultados[8]);
    simular_working_set(REFS_DEFECTO, &resultados[9]);
    simular_wsclock(REFS_DEFECTO, &resultados[10]);
    simular_aleatorio(REFS_DEFECTO, &resultados[11]);

    printf("****************************************************************************************************\n");
    printf("*                SIMULADOR DE ALGORITMOS DE REEMPLAZO DE PAGINAS EN LENGUAJE C                     *\n");
    printf("*                Configuracion: 3 Marcos de Memoria | 30 Referencias de Pagina                     *\n");
    printf("****************************************************************************************************\n");

    for (int i = 0; i < NUM_ALGOS; i++) {
        imprimir_matriz_algoritmo(REFS_DEFECTO, &resultados[i]);
    }

    printf("\n\n=========================================================================================\n");
    printf("                       TABLA COMPARATIVA CONSOLIDADA DE LOS 12 ALGORITMOS                \n");
    printf("=========================================================================================\n");
    printf("%-4s | %-18s | %-14s | %-8s | %-8s | %-11s | %-11s\n",
           "Nro", "Algoritmo", "Responsable", "Fallos", "Aciertos", " % Fallos", " % Aciertos");
    printf("-----------------------------------------------------------------------------------------\n");
    for (int i = 0; i < NUM_ALGOS; i++) {
        printf("%2d   | %-18s | %-14s | %6d   | %6d   | %9.2f%%  | %9.2f%%\n",
               i + 1,
               resultados[i].nombre,
               resultados[i].integrante,
               resultados[i].fallos,
               resultados[i].aciertos,
               resultados[i].tasa_fallos,
               resultados[i].tasa_aciertos);
    }
    printf("=========================================================================================\n");

    exportar_csv("proyecto_zip/resultados/resultados_simulacion.csv", resultados);
    return 0;
}
